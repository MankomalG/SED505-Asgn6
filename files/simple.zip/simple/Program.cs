﻿using HashedFeatureSimple;

public class Program
{
    public static void Main(string[] args)
    {
        SimpleExampleProgram.Run(args);
    }
}

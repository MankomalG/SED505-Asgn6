﻿namespace HashedFeatureCTR;

public class Program
{
    public static void Main(string[] args)
    {
        CtrExampleProgram.Run(args);
    }
}
